#include <iostream>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <limits>

using namespace std;

class phuong_tien {
private:
    int ma_xe;
    string loai_xe;
    int gio_vao;
    int tg_do;

public:
    phuong_tien();
    phuong_tien(int ma, string loai, int gio, int tg);

    int lay_ma_xe() const;
    string lay_loai_xe() const;
    double tinh_phi() const;
    void hien_thi() const;
};

phuong_tien::phuong_tien() : ma_xe(0), loai_xe(""), gio_vao(0), tg_do(0) {}

phuong_tien::phuong_tien(int ma, string loai, int gio, int tg)
    : ma_xe(ma), loai_xe(loai), gio_vao(gio), tg_do(tg) {}

int phuong_tien::lay_ma_xe() const { return ma_xe; }
string phuong_tien::lay_loai_xe() const { return loai_xe; }

double phuong_tien::tinh_phi() const {
    double gia = (loai_xe == "Car") ? 6.0 : (loai_xe == "Motorcycle") ? 4.0 : 2.0;
    bool cao_diem = (gio_vao >= 6 && gio_vao <= 9) || (gio_vao >= 15 && gio_vao <= 18);
    double tong = 0;
    for (int h = 0; h < tg_do; ++h) {
        if (h < 2) tong += gia * (cao_diem ? 1.30 : 0.95);
        else       tong += gia * 0.90;
    }
    return tong;
}

void phuong_tien::hien_thi() const {
    cout << "  ID: " << ma_xe << " | " << loai_xe
         << " | " << gio_vao << "h | " << tg_do << "h"
         << " | Phi: $" << fixed << setprecision(2) << tinh_phi() << "\n";
}

class bai_xe {
private:
    int ma_bai;
    char kich_thuoc;
    
    static const int MAX_VEHICLES = 3;
    phuong_tien vehicles[MAX_VEHICLES];
    int currentVehicleCount;

public:
    bai_xe();
    bai_xe(int ma, char kt);

    int lay_ma() const;
    char lay_kich_thuoc() const;
    int getCapacity() const;
    int getCurrentVehicleCount() const;

    bool isFull() const;
    bool them(const phuong_tien& v);
    bool xoa(int ma_xe);
    int tim_vi_tri_xe(int ma_xe) const;
    bool chua(int ma_xe) const;
    void hien_thi() const;
    bool co_loai(string loai, int& dem, double& tong) const;
};

bai_xe::bai_xe() : ma_bai(0), kich_thuoc('S'), currentVehicleCount(0) {}

bai_xe::bai_xe(int ma, char kt) : ma_bai(ma), kich_thuoc(kt), currentVehicleCount(0) {}

int bai_xe::lay_ma() const { return ma_bai; }
char bai_xe::lay_kich_thuoc() const { return kich_thuoc; }

int bai_xe::getCapacity() const {
    if (kich_thuoc == 'S') return 1;
    if (kich_thuoc == 'M') return 2;
    return 3;
}

int bai_xe::getCurrentVehicleCount() const { return currentVehicleCount; }

bool bai_xe::isFull() const {
    return currentVehicleCount >= getCapacity();
}

int bai_xe::tim_vi_tri_xe(int ma_xe) const {
    for (int i = 0; i < currentVehicleCount; ++i) {
        if (vehicles[i].lay_ma_xe() == ma_xe) {
            return i;
        }
    }
    return -1;
}

bool bai_xe::chua(int ma_xe) const {
    return tim_vi_tri_xe(ma_xe) != -1;
}

bool bai_xe::them(const phuong_tien& v) {
    if (isFull()) return false;
    vehicles[currentVehicleCount] = v;
    currentVehicleCount++;
    return true;
}

bool bai_xe::xoa(int ma_xe) {
    int idx = tim_vi_tri_xe(ma_xe);
    if (idx == -1) return false;

    for (int i = idx; i < currentVehicleCount - 1; ++i) {
        vehicles[i] = vehicles[i + 1];
    }
    currentVehicleCount--;
    return true;
}

void bai_xe::hien_thi() const {
    int cap = getCapacity();
    cout << "Bai " << ma_bai << " [" << kich_thuoc << "] "
         << currentVehicleCount << "/" << cap << " xe\n";
    for (int i = 0; i < currentVehicleCount; ++i) {
        vehicles[i].hien_thi();
    }
}

bool bai_xe::co_loai(string loai, int& dem, double& tong) const {
    dem = 0; tong = 0;
    for (int i = 0; i < currentVehicleCount; ++i) {
        if (vehicles[i].lay_loai_xe() == loai) {
            ++dem;
            tong += vehicles[i].tinh_phi();
        }
    }
    return dem > 0;
}

class SystemInterface {
private:
    static const int MAX_LOTS = 10;
    bai_xe parkingLots[MAX_LOTS];
    int currentLotCount;

    int generateRandomID() const;
    void clearInputBuffer();

public:
    SystemInterface();
    void runMenu();
    bool isParkIDExists(int pID) const;
    bool isVehicleIDExists(int vID) const;
};

SystemInterface::SystemInterface() : currentLotCount(0) {
    srand(static_cast<unsigned int>(time(NULL)));
}

void SystemInterface::clearInputBuffer() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

int SystemInterface::generateRandomID() const {
    return 1000 + rand() % 9000;
}

bool SystemInterface::isParkIDExists(int pID) const {
    for (int i = 0; i < currentLotCount; ++i) {
        if (parkingLots[i].lay_ma() == pID) return true;
    }
    return false;
}

bool SystemInterface::isVehicleIDExists(int vID) const {
    for (int i = 0; i < currentLotCount; ++i) {
        if (parkingLots[i].chua(vID)) return true;
    }
    return false;
}

void SystemInterface::runMenu() {
    int chon = 0;
    do {
        cout << "\n===== QUAN LY BAI DO XE (GIAI DOAN 2) =====\n";
        cout << "1. Tao bai do moi\n";
        cout << "2. Them xe vao bai do\n";
        cout << "3. Xoa mot Bai do xe\n";
        cout << "4. Lay xe ra khoi bai do\n";
        cout << "5. Hien thi danh sách tất cả các Bai do xe\n";
        cout << "6. Hien thi danh sách xe theo bai cụ thể\n";
        cout << "7. Liet ke xe theo loại phương tiện\n";
        cout << "8. Tóm tắt phí đỗ xe trung bình\n";
        cout << "9. Thoat\n";
        cout << "Chon chuc nang (1-9): ";
        
        if (!(cin >> chon)) {
            cout << "[Loi] Vui lòng nhập số nguyên hợp lệ!\n";
            clearInputBuffer();
            continue;
        }

        switch (chon) {
            case 1: {
                if (currentLotCount >= MAX_LOTS) {
                    cout << "[Thong bao] Mang parkingLots da dat toi da MAX_LOTS (10 bai)!\n";
                    break;
                }
                int ma; char kt;
                cout << "Nhập mã bãi đỗ: ";
                if (!(cin >> ma)) { cout << "[Loi] Sai kiểu dữ liệu!\n"; clearInputBuffer(); break; }
                
                cout << "Nhập kích thước (S/M/L): ";
                cin >> kt;

                if (isParkIDExists(ma)) {
                    int newID = generateRandomID();
                    while (isParkIDExists(newID)) { newID = generateRandomID(); }
                    cout << "[Cảnh báo] Mã bãi đỗ " << ma << " đã tồn tại! Tự động đổi thành ID ngẫu nhiên: " << newID << "\n";
                    ma = newID;
                }

                parkingLots[currentLotCount] = bai_xe(ma, kt);
                currentLotCount++;
                cout << "Đã tạo thành công bãi đỗ " << ma << " [" << kt << "]\n";
                break;
            }
            case 2: {
                if (currentLotCount == 0) {
                    cout << "[Thong bao] Hệ thống chưa có bãi đỗ nào được tạo!\n";
                    break;
                }
                int ma, gio, tg; string loai;
                cout << "Nhập mã xe: ";
                if (!(cin >> ma)) { cout << "[Loi] Sai kiểu dữ liệu!\n"; clearInputBuffer(); break; }

                if (isVehicleIDExists(ma)) {
                    int newID = generateRandomID();
                    while (isVehicleIDExists(newID)) { newID = generateRandomID(); }
                    cout << "[Cảnh báo] Mã xe " << ma << " đã tồn tại trong hệ thống! Tự động gán ID mới: " << newID << "\n";
                    ma = newID;
                }

                cout << "Nhập loại xe (Car/Motorcycle/Bicycle): ";
                cin >> loai;
                cout << "Nhập giờ vào (0-23): ";
                if (!(cin >> gio)) { cout << "[Loi] Sai kiểu dữ liệu!\n"; clearInputBuffer(); break; }
                cout << "Nhập thời lượng đỗ (giờ): ";
                if (!(cin >> tg)) { cout << "[Loi] Sai kiểu dữ liệu!\n"; clearInputBuffer(); break; }

                phuong_tien v(ma, loai, gio, tg);
                bool added = false;
                
                for (int i = 0; i < currentLotCount; ++i) {
                    if (!parkingLots[i].isFull()) {
                        parkingLots[i].them(v);
                        added = true;
                        cout << "Đã tự động xếp xe " << ma << " vào Bãi " << parkingLots[i].lay_ma() 
                             << " | Phí dự kiến: $" << fixed << setprecision(2) << v.tinh_phi() << "\n";
                        break;
                    }
                }

                if (!added) {
                    cout << "[Cảnh báo] Tất cả các bãi đỗ hiện có đều đã đầy!\n";
                }
                break;
            }
            case 3: {
                int ma;
                cout << "Nhập mã bãi đỗ cần xóa: ";
                if (!(cin >> ma)) { cout << "[Loi] Sai kiểu dữ liệu!\n"; clearInputBuffer(); break; }

                int lotIdx = -1;
                for (int i = 0; i < currentLotCount; ++i) {
                    if (parkingLots[i].lay_ma() == ma) {
                        lotIdx = i;
                        break;
                    }
                }

                if (lotIdx == -1) {
                    cout << "[Thong bao] Không tìm thấy bãi đỗ có mã " << ma << "\n";
                } else {
                    for (int i = lotIdx; i < currentLotCount - 1; ++i) {
                        parkingLots[i] = parkingLots[i + 1];
                    }
                    currentLotCount--;
                    cout << "Đã xóa thành công bãi đỗ " << ma << " và dồn mảng hệ thống.\n";
                }
                break;
            }
            case 4: {
                int ma;
                cout << "Nhập mã xe cần lấy ra: ";
                if (!(cin >> ma)) { cout << "[Loi] Sai kiểu dữ liệu!\n"; clearInputBuffer(); break; }

                bool removed = false;
                for (int i = 0; i < currentLotCount; ++i) {
                    if (parkingLots[i].chua(ma)) {
                        parkingLots[i].xoa(ma);
                        removed = true;
                        break;
                    }
                }

                if (removed) {
                    cout << "Đã lấy xe " << ma << " ra khỏi bãi thành công.\n";
                } else {
                    cout << "[Thong bao] Không tìm thấy xe có mã " << ma << " trong toàn bộ hệ thống.\n";
                }
                break;
            }
            case 5: {
                if (currentLotCount == 0) {
                    cout << "[Thong bao] Hệ thống chưa có bãi đỗ nào.\n";
                    break;
                }
                cout << "\n--- DANH SÁCH TẤT CẢ CÁC BÃI ĐỖ ---\n";
                for (int i = 0; i < currentLotCount; ++i) {
                    parkingLots[i].hien_thi();
                    cout << "------------------------------------\n";
                }
                break;
            }
            case 6: {
                int ma;
                cout << "Nhập mã bãi đỗ cần xem: ";
                if (!(cin >> ma)) { cout << "[Loi] Sai kiểu dữ liệu!\n"; clearInputBuffer(); break; }

                bool found = false;
                for (int i = 0; i < currentLotCount; ++i) {
                    if (parkingLots[i].lay_ma() == ma) {
                        parkingLots[i].hien_thi();
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    cout << "[Thong bao] Không tìm thấy bãi đỗ mã " << ma << "\n";
                }
                break;
            }
            case 7: {
                string loai;
                cout << "Nhập loại xe cần liệt kê (Car/Motorcycle/Bicycle): ";
                cin >> loai;

                cout << "\n--- KẾT QUẢ LỌC XE THEO LOẠI: " << loai << " ---\n";
                bool anyFound = false;
                for (int i = 0; i < currentLotCount; ++i) {
                    int dem = 0; double tong = 0;
                    if (parkingLots[i].co_loai(loai, dem, tong)) {
                        cout << "Bãi " << parkingLots[i].lay_ma() << " có " << dem << " xe phù hợp:\n";
                        anyFound = true;
                    }
                }
                if (!anyFound) {
                    cout << "Không tìm thấy xe loại " << loai << " nào trong hệ thống.\n";
                }
                break;
            }
            case 8: {
                string loai_arr[3] = {"Car", "Motorcycle", "Bicycle"};
                cout << "\n--- BÁO CÁO PHÍ ĐỖ XE TRUNG BÌNH ---\n";
                for (int t = 0; t < 3; ++t) {
                    int totalDem = 0; double totalTong = 0;
                    for (int i = 0; i < currentLotCount; ++i) {
                        int d = 0; double s = 0;
                        if (parkingLots[i].co_loai(loai_arr[t], d, s)) {
                            totalDem += d;
                            totalTong += s;
                        }
                    }
                    cout << "- Loại " << loai_arr[t] << ": ";
                    if (totalDem == 0) {
                        cout << "Không có xe nào trên hệ thống.\n";
                    } else {
                        cout << totalDem << " xe | Phí trung bình: $" << fixed << setprecision(2) << (totalTong / totalDem) << "\n";
                    }
                }
                break;
            }
            case 9:
                cout << "Đang thoát chương trình. Tạm biệt!\n";
                break;
            default:
                cout << "[Loi] Lựa chọn không hợp lệ. Vui lòng chọn từ 1 đến 9.\n";
        }
    } while (chon != 9);
}

int main() {
    SystemInterface sys;
    sys.runMenu();
    return 0;
}
